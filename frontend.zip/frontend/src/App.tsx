import { useEffect, useMemo, useState } from "react";

/**
 * หน้าเว็บการจองโต๊ะของร้านอาหาร
 * - ร้านชื่อ "ร้านนายสมชาย" แสดงตัวใหญ่อยู่ในกรอบสี่เหลี่ยมสีฟ้าอ่อน
 * - แสดงเวลาแบบตัวอย่าง "11:06 PM 17/7/2025" (อัปเดตอัตโนมัติทุกนาที)
 * - มี 20 โต๊ะ: ว่าง = สีเขียว, มีคน = สีเทา, เมื่อเอาเมาส์วาง = ขอบสีฟ้าอ่อน
 * - มุมบนขวาบอกประเภทผู้ใช้
 */

// helper แปลงวันที่เป็นรูปแบบ "hh:mm AM/PM DD/M/YYYY"
function formatDateTime(d: Date) {
  const hours12 = d.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
  const day = d.getDate();
  const month = d.getMonth() + 1; // 0-11
  const year = d.getFullYear();
  return `${hours12} ${day}/${month}/${year}`;
}

// ประเภทสถานะโต๊ะ
type TableStatus = "free" | "occupied";

// ข้อมูลโต๊ะ
interface TableInfo {
  id: number;
  status: TableStatus;
}

interface Props {
  userType?: string; // ประเภทผู้ใช้ที่มุมขวาบน
}

export default function TableReservationPage({ userType = "ลูกค้า" }: Props) {
  const [now, setNow] = useState<Date>(new Date());

  // mock สถานะเริ่มต้นของ 20 โต๊ะ (สุ่มเล็กน้อย)
  const [tables, setTables] = useState<TableInfo[]>(() => {
    return Array.from({ length: 20 }, (_, i) => ({
      id: i + 1,
      status: Math.random() < 0.25 ? "occupied" : "free", // เริ่มต้นมีคน ~25%
    }));
  });

  // อัปเดตเวลาเป็นนาที (ลดการ refresh บ่อย)
  useEffect(() => {
    const tick = setInterval(() => setNow(new Date()), 60 * 1000);
    return () => clearInterval(tick);
  }, []);

  const timeLabel = useMemo(() => formatDateTime(now), [now]);

  // toggle สถานะโต๊ะเมื่อคลิก
  const toggleTable = (id: number) => {
    setTables((prev) =>
      prev.map((t) =>
        t.id === id ? { ...t, status: t.status === "free" ? "occupied" : "free" } : t
      )
    );
  };

  // confirmBooking ยืนยันการจอง
  const confirmBooking = () => {
    const bookedTables = tables.filter((table) => table.status === "free");
    if (bookedTables.length === 0) {
      alert("กรุณาเลือกโต๊ะก่อน");
      return;
    }
  }

  

  return (
    //หน้าตา
  <div className="min-h-screen bg-gray-50 p-4 md:p-6">
    {/* Top bar: ชื่อร้าน + เวลา + ประเภทผู้ใช้ */}
    <div className="relative w-full rounded-2xl border border-sky-200 bg-sky-50 px-6 py-4 shadow-sm">
      {/* ประเภทผู้ใช้ มุมบนขวา */}
      <div className="absolute top-4 right-4">
        <div className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2 shadow-sm">
          <span className="text-sm text-slate-500">ประเภทผู้ใช้</span>
          <span className="rounded-xl bg-slate-100 px-2 py-1 text-sm font-semibold text-slate-700">{userType}</span>
        </div>
      </div>

      {/* ชื่อร้าน */}
      <h1 className="text-3xl md:text-4xl font-bold text-slate-800">ร้านนายสมชาย</h1>

      {/* เวลา */}
      <div className="mt-2 text-sm text-slate-700">
        เวลา: <span className="font-medium">{timeLabel}</span>
      </div>
    </div>

      {/* ตารางโต๊ะ */}
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        {tables.map((table) => {
          const isFree = table.status === "free";
          return (
            <button
              key={table.id}
              onClick={() => toggleTable(table.id)}
              className={[
                "group relative h-28 w-full rounded-2xl p-4 text-left shadow-sm transition",
                "hover:ring-2 hover:ring-sky-200 focus:outline-none focus:ring-2 focus:ring-sky-300",
                isFree ? "bg-green-500 text-white" : "bg-gray-300 text-slate-700",
              ].join(" ")}
              aria-pressed={isFree ? "false" : "true"}
              aria-label={`โต๊ะ ${table.id} ${isFree ? "ว่าง" : "มีคน"}`}
            >
              <div className="flex h-full flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold">โต๊ะ {table.id}</span>
                  <span className="rounded-xl bg-white/30 px-2 py-0.5 text-xs font-semibold text-white mix-blend-luminosity">
                    {isFree ? "ว่าง" : "มีคน"}
                  </span>
                </div>
                <div className="text-xs opacity-90">
                  <span>คลิกเพื่อ{isFree ? "จอง" : "ปลดจอง"}</span>
                </div>
              </div>

              {/* เส้นไฮไลต์เมื่อ hover (โชว์ชัดเจนขึ้น) */}
              <div className="pointer-events-none absolute inset-0 rounded-2xl ring-0 ring-sky-200 transition-all group-hover:ring-2" />
            </button>
          );
        })}
        {/* ปุ่มยืนยันการจอง */}
              <div className="mt-6 flex justify-center">
                <button
                  onClick={confirmBooking}
                  className="fixed bottom-4 right-4 rounded-2xl bg-sky-500 px-6 py-3 text-white font-semibold shadow-md transition"
                >
                  ยืนยันการจอง
                </button>
                <button
                  onClick={confirmBooking}
                  className="fixed bottom-4 right-46 rounded-2xl bg-red-500 px-6 py-3 text-white font-semibold shadow-md transition"
                >
                  ยกเลิกการจอง
                </button>
              </div>
      </div>
    </div>
  );
}


//export default App
